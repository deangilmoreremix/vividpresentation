// import React from "react";
// import { Projects } from "../projects";
// import { getAllProjects } from "@/actions/project";

// export const TabsContentComponent = async () => {
//   const allProjects = await getAllProjects();
//   // console.log(allProjects);
//   return (
//     <React.Fragment>
//       <div >
//         {allProjects?.data?.length ?? 0 > 0 ? (
//           <Projects projects={allProjects.data} />
//         ) : (
//           <div>Nothing to see</div>
//         )}
//       </div>
//     </React.Fragment>
//   );
// };
