import { NotFound } from '@/components/global/not-found'
import React from 'react'


const Custom404 = () => {
  return (
    <NotFound/>
  )
}

export default Custom404